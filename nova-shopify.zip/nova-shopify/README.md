# NOVA Shopify Theme

Premium luxury streetwear theme with WebGL animations, minimalist design, and full Shopify integration.

## Installation

1. Download `nova-shopify.zip`
2. Shopify Admin → Online Store → Themes
3. Click **Upload theme**
4. Select the ZIP file
5. Click **Upload**

## Theme Files

- **layout/theme.liquid** - Main layout template
- **sections/** - Hero, navbar, featured products, footer
- **templates/** - Index, product, collection pages
- **assets/** - CSS and JavaScript with animations
- **config/** - Settings and theme configuration

## Sections (Editable in Shopify)

### Hero
- Customizable heading, tagline, description
- Animated scroll indicator
- Full-screen layout

### Featured Products
- Select a collection to display
- Shows 3 products with images and prices
- Hover animations

### Navbar
- Shop, Story, Contact links
- Shop Now button
- Fixed positioning

### Footer
- Link sections (Shop, Customer, Brand, Connect)
- Social media links
- Copyright

## Customization

### Colors
Edit in Shopify Theme Settings:
- Accent Color (default: #CA8A04 - Gold)
- Text Color (default: #0C0A09 - Dark)
- Background Color (default: #FAFAF9 - Off-white)

### Fonts
Uses Google Fonts (auto-imported):
- **Bodoni Moda** - Headings (luxury, serif)
- **Jost** - Body text (minimalist, sans-serif)

## Features

✨ **Animations**
- WebGL background with Three.js
- Scroll fade-in effects
- Hover animations on product cards
- Parallax scrolling

🎨 **Design**
- Dark minimalist aesthetic
- Gold accent color
- Premium typography
- Fully responsive

♿ **Accessibility**
- Semantic HTML
- WCAG compliant
- Reduced motion support
- Proper image alt text

## Support

For questions, visit: https://instagram.com/novaly.us

---

Made with ❤️ for NOVA Streetwear

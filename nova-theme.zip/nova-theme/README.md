# NOVA Shopify Theme

A premium luxury streetwear theme for Shopify with advanced animations and minimalist design.

## Features

- **WebGL Animated Background** - Three.js powered animated geometry
- **Dark Minimalist Design** - Charcoal base with gold accents
- **Premium Typography** - Bodoni Moda (headings) + Jost (body)
- **Product Showcase** - Grid layout with hover animations
- **Smooth Animations** - Scroll effects, fade-ins, and micro-interactions
- **Fully Responsive** - Mobile-first design
- **Accessibility** - WCAG compliant with reduced-motion support

## Installation

1. Log in to your Shopify admin
2. Go to **Online Store > Themes**
3. Click **Upload theme**
4. Select this ZIP file
5. Click **Upload**

## Customization

### Colors
Edit colors in `/config/settings_schema.json`:
- Accent Color: `#CA8A04` (gold)
- Primary Color: `#1C1917` (dark brown)

### Fonts
All fonts are from Google Fonts:
- Headings: Bodoni Moda
- Body: Jost

Update in `/layout/theme.liquid` if needed.

### Sections
- **navbar** - Navigation header
- **hero** - Hero section with tagline
- **products** - Product grid (pulls from collection)
- **footer** - Footer with links

## File Structure

```
nova-theme/
├── assets/
│   ├── nova-theme.css       # All styles
│   └── nova-theme.js        # JavaScript & animations
├── config/
│   └── settings_schema.json  # Theme settings
├── layout/
│   └── theme.liquid          # Main layout
├── sections/
│   ├── navbar.liquid
│   ├── hero.liquid
│   ├── products.liquid
│   └── footer.liquid
├── templates/
│   └── product.liquid        # Product page template
└── README.md
```

## Support

For issues or customization needs, visit: https://instagram.com/novaly.us

---

Made with ❤️ for NOVA Streetwear
